import re
from datetime import datetime, date

teks = """Pada tanggal 1945-08-17 Indonesia merdeka. Indonesia memiliki beberapa pahlawan
        nasional, seperti Pangeran Diponegoro (TL: 1785-11-11), Pattimura (TL: 1783-06-08) 
        dan Ki Hajar Dewantara (1889-05-02)."""

tanggal = re.findall(r'\b(\d{4}-\d{2}-\d{2})\b', teks)

hasil = []
for tgl in tanggal:
    tgl_obj = datetime.strptime(tgl, '%Y-%m-%d')

    tgl_str = tgl_obj.strftime('%d-%m-%Y')
    
    selisih = (date.today() - tgl_obj.date()).days
    
    hasil.append(f'{tgl_str} selisih dari hari ini adalah {selisih} hari')

for h in hasil:
    print(h)

