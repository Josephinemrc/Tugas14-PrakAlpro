import re
import secrets
import string

teks = """Berikut adalah daftar email dan nama pengguna dari mailing list: anton@mail.com dimiliki oleh 
antonius budi@gmail.co.id dimiliki oleh budi anwari slamet@getnada.com dimiliki oleh slamet slumut 
matahari@tokopedia.com dimiliki oleh toko matahari"""

daftar_email = re.findall(r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b', teks)

def buat_pass(panjang=8):
    karakter = string.ascii_letters + string.digits
    pswrd = ''.join(secrets.choice(karakter) for _ in range(panjang))
    return pswrd

for email in daftar_email:
    username = email.split('@')[0]
    pswrd = buat_pass()
    print(f"{email} username: {username}, password: {pswrd}")

